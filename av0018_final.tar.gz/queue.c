/**
 *
 * @author Akash Rajendra Ventekar
 * Class: CS-590
 * Date: 08/09/2016
 * C program to create a producer and consumer threads using the pthread library.		
 * Reference of concepts: http://www.mathcs.emory.edu/~cheung/Courses/171/Syllabus/8-List/array-queue2.html
 */

//Header files
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <math.h>
#define BUFFER_SIZE 100

//Declaration variables
int produce = 0, consume = 0;			// Iterators
int circ_buff[BUFFER_SIZE];			// Requirement 2.a: Shared Buffer for storing 100 integers
unsigned int z = 1;				// Used for random generation, also a shared variable
pthread_mutex_t mutex_lock;			// Mutex lock variable
pthread_cond_t cond_var_prod,cond_var_con; 	// Condition variables for producer and consumer. Can't use one condition variable as, consumer has to wait on producer and producer has to wait  on consumer

/* Requirment 3,4: Random generator for generation of random integers from 1 to 1000 and sleep time from 1 to 3 */
int random_gen(int divisor)
{
	unsigned int *seed;			// Seed for random generation
	seed = &z;
	z = ((z+1)*5) % 27000;			// Mod 27000 to prevent buffer overflow
	return (rand_r(seed) % divisor) + 1;	// Requirment 6:Return random number generated using thread safe function rand_r
}

/* Producer function */
void *prod_enqueue(void *arg)
{
	int sleep_time;				
	int integer;
	sleep(2); 				// Helps in printing the consumer and producer thread creation before execution
	while(1){				// Requirment 5:Run endlessly. Can be substituted with do_while or for as well.
		pthread_mutex_lock(&mutex_lock);// Lock the mutex and enter the critical section
		integer = random_gen(1000);     // Get the random value from 1 to 1000
		while(circ_buff[produce] != 0)	// Requirement 3.a: Buffer full condition. This is not generic. But, a better solution for this specific program 
        	{
        	        printf("Buffer is full\n");
			pthread_cond_wait(&cond_var_con, &mutex_lock);	//Wait on consumer to consume an item
		}	
		circ_buff[produce] = integer;	// Store the integer in the index
		printf("Producer %lu: Enqueued %d into %d index. ", pthread_self(), integer, produce);	// Requirment 3.b: Print a message with thread_id, integer inserted and index
		produce = (produce + 1) % BUFFER_SIZE;		// Requirement 2: Index back to 0, if 100
		sleep_time = random_gen(3);                     // Sleep for a random time between 1 to 3 seconds
		printf("Producer %lu: Sleeping for %d seconds\n", pthread_self(), sleep_time);  // Print the sleep time
		pthread_mutex_unlock(&mutex_lock);		// Unlock mutex
		pthread_cond_signal(&cond_var_prod);		// Signal ateast one consumer that an item has been enqueued
                sleep(sleep_time);				// Call sleep function
	}
	return ((void *) 1);
}

/* Consumer function */
void  *con_dequeue(void *arg)
{
	int integer;
	int sleep_time;
	sleep(2);					// Helps in printing the consumer and producer thread creation before execution
	while(1){					// Requirement 5: Run endlessly
		pthread_mutex_lock(&mutex_lock);	// Lock the mutex and enter the critical section
		while(circ_buff[consume] == 0)		// Requirement 4.a: Buffer empty condition. 
		{
			printf("Buffer is empty\n");
			pthread_cond_wait(&cond_var_prod, &mutex_lock);	//Wait on producer to produce an item
		}
		integer = circ_buff[consume];		// Get the integer stored in the index
		circ_buff[consume] = 0;			// Reinitiliaze to 0 after getting the integer (Consume operation)
		printf("Consumer %lu: Consumed %d at %d index. ", pthread_self(), integer, consume);	// Requirement 4.b: Print a message with thread_id, integer consumed and index
		consume = (consume + 1) % BUFFER_SIZE;	// Requirement 2: Index back to 0, if 100
		sleep_time = random_gen(3);             // Sleep for a random time between 1 to 3 seconds
		printf("Consumer %lu: Sleeping for %d seconds\n", pthread_self(), sleep_time);  // Print the sleep time
		pthread_mutex_unlock(&mutex_lock);	// unlock mutex
		pthread_cond_signal(&cond_var_con);	// Signal atleast one producer that an item has been consumed
                sleep(sleep_time);			// Call sleep function
	}	
	return ((void *) 1);
}

/* Main function */
int main()
{
	// Declaration of variables
	int i, num_prod, num_con, error;	// iterator, number of producers and consumers, error
	pthread_t con[100], prod[100];		// Consumer and producer threads
	int err[100],err1[100];			// To check for an error for thread creation or thread join 
	void *tret;				// Return status of the thread. "Not required as threads are going to run endlessly"
	
	/* Requirment 7 */
	pthread_mutex_init(&mutex_lock, NULL);	// Initialize mutex 
	pthread_cond_init(&cond_var_prod, NULL);// Initialize producer condition variable
	pthread_cond_init(&cond_var_con, NULL);	// Initialize consumer condition variable

	printf("Enter the number of producers\n");
	scanf("%d", &num_prod);			// Requirement 1: Get number of producers
	printf("Enter the number of consumers\n");
	scanf("%d", &num_con);			// Get number of consumers
	
	printf("Producers :\n");	
	for(i = 0;i < num_prod; i++)		// Create producer threads, exit even if one thread creation fails 
	{
		err[i] = pthread_create(&prod[i], NULL, prod_enqueue, NULL);	// Create thread to run producer function
		if (err[i] != 0){	// Error in thread creation
        	        printf("Can't create thread");
			exit(1);
		}
		printf("Created producer thread with thread id: %lu\n", prod[i]);
	}
	
	printf("Consumers :\n");
	for(i = 0;i < num_con; i++)		//// Create consumer threads, exit even if one thread creation fails
        {
	        err1[i] = pthread_create(&con[i], NULL, con_dequeue, NULL);	//Create thread to consumer function
		if (err1[i] != 0){	//Error in thread creation
	                printf("Can't create thread");
			exit(1);
		}
		printf("Created consumer thread with thread id: %lu\n", con[i]);
		//Suspend execution of the calling thread until the specified thread terminates. Since, none of the thread exits. We can use one thread or use a for loop listing consumer and producer threads
		if(i+1 == num_con){	//Suspend the calling thread after creation of last consumer thread
			error = pthread_join(con[i], &tret);	//Requirment 5.
                	if (error != 0)
                        	printf("Can't join with thread %lu",con[i]);
                	printf("thread %lu : exit code %ld\n", con[i], (long)tret);
		}
	}
	/*while(1)	//This is a hack if required to stop thread from exiting
	{
		sleep(1000);
	}*/

	/* Free mutex and condition variables, not required */
	pthread_mutex_destroy(&mutex_lock);	
	pthread_cond_destroy(&cond_var_prod);
	pthread_cond_destroy(&cond_var_con);
	
	return 0;
}
